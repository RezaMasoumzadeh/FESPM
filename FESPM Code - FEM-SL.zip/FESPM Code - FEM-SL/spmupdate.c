#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "spm.h"
#include "fespm.h"

ErrorCode FESLSPMComputeTimestep_CFL(FESLSPM s, double uh[], double *dt);

/*
 Define diffusivity as a constant

 kappa(x) = const.

 Notes:
 - This form of diffusion model is commonly used in large scale geodynamic modelling
 - For example see


 [1] H.D. Sinclair, B.J. Coakley, P.A. Allen and A.B. Watts
 "SIMULATION OF FORELAND BASIN STRATIGRAPHY USING
 A DIFFUSION MODEL OF MOUNTAIN BELT UPLIFT AND EROSION:
 AN EXAMPLE FROM THE CENTRAL ALPS, SWITZERLAND",
 Tectonics (1991) Vol 10, No. 3, 599-620

 [2] Guy D. H. Simpson,
 "Modelling interactions between fold-thrust belt
 deformation, foreland flexure and surface mass
 transport",
 Basin Research (2006) 18, 125–143, doi: 10.1111/j.1365-2117.2006.00287.x

 [3] E. Burov, G. Toussaint,
 "Surface processes and tectonics: Forcing of continental
 subduction and deep processes",
 Global and Planetary Change (2007) 58, 141–164

*/
ErrorCode FESLSPMComputeDiffusivity_Constant(FESLSPM s, double h[])
{
  ErrorCode ierr;

  CentroidIteratorBegin(s)

      s->kappa[CellIdx(s, mi, mj)] = s->k0;

  CentroidIteratorEnd(s)

      return (0);
}

ErrorCode FESLSPMComputeDiffusivity_Constant_SACoeff(FESLSPM s, double h[])
{
  ErrorCode ierr;

  CentroidIteratorBegin(s)
  {
    double avg = 0.0;
    avg += s->k0_n[NodeIdx(s, mi, mj)];
    avg += s->k0_n[NodeIdx(s, mi + 1, mj)];
    avg += s->k0_n[NodeIdx(s, mi, mj + 1)];
    avg += s->k0_n[NodeIdx(s, mi + 1, mj + 1)];
    s->kappa[CellIdx(s, mi, mj)] = 0.25 * avg;
  }
  CentroidIteratorEnd(s)

      return (0);
}

/*
 Define diffusivity as function of the gradient of the slope and a critical slope angle.

 kappa(x) = k0 . [ 1 - (|| grad(h) ||/Sc)^m ]^{-1}

 where
   Sc is the critical surface slope, defined as tan(theta) = Sc
   m is a the non-linear exponent
   || grad(h) || = sqrt( (\partial h / \partial x)^2 + (\partial h / \partial y)^2 )

 Notes:
 - Typically commonly used in hillslope large scale geomorph modelling
 - The exponent is usually taken as m=2
 - For example see

 [1] Joshua J. Roering, James W. Kirchner, and William E. Dietrich,
 "Evidence for nonlinear, diffusive sediment transport on
 hillslopes and implications for landscape morphology",
 WATER RESOURCES RESEARCH (1999) VOL. 35, NO. 3, PAGES 853-870

 [2] Joshua J. Roering,
 "How well can hillslope evolution models "explain" topography?
 Simulating soil transport and production with high-resolution
 topographic data"
 GSA Bulletin (2008) v. 120, no. 9/10, 1248-1262, doi: 10.1130/B26283.1

 [3] J. Taylor Perron,
 "Numerical methods for nonlinear hillslope transport laws"
 JOURNAL OF GEOPHYSICAL RESEARCH (2001) VOL. 116, F02021, doi:10.1029/2010JF001801

*/
ErrorCode FESLSPMComputeDiffusivity_NonlinearCriticalSlope(FESLSPM s, double h[])
{
  ErrorCode ierr;
  double kstar, gradh[2], norm, avghx[2], avghy[2], nls;
  int ni, nj, nid, cid_ij;

  CentroidIteratorBegin(s)
      cid_ij = CellIdx(s, mi, mj);

  ni = mi;
  nj = mj;

  avghx[1] = 0.5 * (h[NodeIdx(s, ni + 1, nj)] + h[NodeIdx(s, ni + 1, nj + 1)]);
  avghx[0] = 0.5 * (h[NodeIdx(s, ni, nj)] + h[NodeIdx(s, ni, nj + 1)]);

  avghy[1] = 0.5 * (h[NodeIdx(s, ni, nj + 1)] + h[NodeIdx(s, ni + 1, nj + 1)]);
  avghy[0] = 0.5 * (h[NodeIdx(s, ni, nj)] + h[NodeIdx(s, ni + 1, nj)]);

  // gradh[0] = (h[NodeIdx(s,ni+1,nj)] - h[NodeIdx(s,ni,nj)])/s->dx;
  // gradh[1] = (h[NodeIdx(s,ni,nj+1)] - h[NodeIdx(s,ni,nj)])/s->dy;

  gradh[0] = (avghx[1] - avghx[0]) / s->dx;
  gradh[1] = (avghy[1] - avghy[0]) / s->dy;

  norm = sqrt(gradh[0] * gradh[0] + gradh[1] * gradh[1]);

  nls = pow(norm / s->Sc, s->d_exp);
  if (nls > 1.0)
  {
    nls = 1.0 - 0.00001;
  }

  kstar = s->k0 / (1.0 - nls);

  if (kstar < 0.0)
  {
    printf("gradh[0] = %1.6e\n", gradh[0]);
    printf("gradh[1] = %1.6e\n", gradh[1]);
    printf("norm = %1.6e\n", norm);
    printf("norm/Sc = %1.6e\n", norm / s->Sc);
    printf("pow(norm/s->Sc,s->d_exp) = %1.6e\n", pow(norm / s->Sc, s->d_exp));
    printf("nls = %1.6e \n", nls);

    printf("1.0 - pow(norm/s->Sc,s->d_exp) = %1.6e\n", 1.0 - pow(norm / s->Sc, s->d_exp));

    // ERRQ("k* < 0");
  }

  s->kappa[cid_ij] = kstar;

  CentroidIteratorEnd(s)

      return (0);
}

ErrorCode FESLSPMComputeDiffusivity_NonlinearCriticalSlope_SACoeff(FESLSPM s, double h[])
{
  ErrorCode ierr;
  double kstar, gradh[2], norm, avghx[2], avghy[2], nls, Sc, d_exp, k0;
  int ni, nj, nid, cid_ij;

  CentroidIteratorBegin(s)
      cid_ij = CellIdx(s, mi, mj);

  ni = mi;
  nj = mj;

  avghx[1] = 0.5 * (h[NodeIdx(s, ni + 1, nj)] + h[NodeIdx(s, ni + 1, nj + 1)]);
  avghx[0] = 0.5 * (h[NodeIdx(s, ni, nj)] + h[NodeIdx(s, ni, nj + 1)]);

  avghy[1] = 0.5 * (h[NodeIdx(s, ni, nj + 1)] + h[NodeIdx(s, ni + 1, nj + 1)]);
  avghy[0] = 0.5 * (h[NodeIdx(s, ni, nj)] + h[NodeIdx(s, ni + 1, nj)]);

  // gradh[0] = (h[NodeIdx(s,ni+1,nj)] - h[NodeIdx(s,ni,nj)])/s->dx;
  // gradh[1] = (h[NodeIdx(s,ni,nj+1)] - h[NodeIdx(s,ni,nj)])/s->dy;

  gradh[0] = (avghx[1] - avghx[0]) / s->dx;
  gradh[1] = (avghy[1] - avghy[0]) / s->dy;

  norm = sqrt(gradh[0] * gradh[0] + gradh[1] * gradh[1]);

  {
    double avg[] = {0.0, 0.0, 0.0};

    avg[0] += s->k0_n[NodeIdx(s, mi, mj)];
    avg[0] += s->k0_n[NodeIdx(s, mi + 1, mj)];
    avg[0] += s->k0_n[NodeIdx(s, mi, mj + 1)];
    avg[0] += s->k0_n[NodeIdx(s, mi + 1, mj + 1)];

    avg[1] += s->d_exp_n[NodeIdx(s, mi, mj)];
    avg[1] += s->d_exp_n[NodeIdx(s, mi + 1, mj)];
    avg[1] += s->d_exp_n[NodeIdx(s, mi, mj + 1)];
    avg[1] += s->d_exp_n[NodeIdx(s, mi + 1, mj + 1)];

    avg[2] += s->Sc_n[NodeIdx(s, mi, mj)];
    avg[2] += s->Sc_n[NodeIdx(s, mi + 1, mj)];
    avg[2] += s->Sc_n[NodeIdx(s, mi, mj + 1)];
    avg[2] += s->Sc_n[NodeIdx(s, mi + 1, mj + 1)];

    k0 = 0.25 * avg[0];
    d_exp = 0.25 * avg[1];
    Sc = 0.25 * avg[2];
  }

  nls = pow(norm / Sc, d_exp);
  if (nls > 1.0)
  {
    nls = 1.0 - 0.00001;
  }

  kstar = k0 / (1.0 - nls);

  if (kstar < 0.0)
  {
    printf("gradh[0] = %1.6e\n", gradh[0]);
    printf("gradh[1] = %1.6e\n", gradh[1]);
    printf("norm = %1.6e\n", norm);
    printf("norm/Sc = %1.6e\n", norm / Sc);
    printf("pow(norm/Sc,d_exp) = %1.6e\n", pow(norm / Sc, d_exp));
    printf("nls = %1.6e \n", nls);

    printf("1.0 - pow(norm/Sc,d_exp) = %1.6e\n", 1.0 - pow(norm / Sc, d_exp));
  }

  s->kappa[cid_ij] = kstar;

  CentroidIteratorEnd(s)

      return (0);
}

/*
 Define diffusivity as function of the gradient of the slope raised to a non-integer power.

 kappa(x) = k0 . || grad(h) ||^m

 where
   m is a the non-linear exponent (non-integer)
   || grad(h) || = sqrt( (\partial h / \partial x)^2 + (\partial h / \partial y)^2 )


 Notes:
 - Only found one example where this law is actually used

 [1] Evgueni Burov,
 "Coupled Lithosphere-Surface Processes in Collision Context"
 Booktitle: Thrust Belts and Foreland Basins, (2007) 3-40.
 DOI: 10.1007/978-3-540-69426-7_1
 Series: Frontiers in Earth Sciences,
 Editors: Olivier Lacombe, Roure François, Jérôme Lavé and Jaume Vergés,
 Publisher: Springer Berlin Heidelberg,
 ISBN: 978-3-540-69425-0,

*/
ErrorCode FESLSPMComputeDiffusivity_NonlinearPowerLaw(FESLSPM s, double h[])
{
  ErrorCode ierr;
  double kstar, gradh[2], norm, avghx[2], avghy[2];
  int ni, nj, nid, cid_ij;

  CentroidIteratorBegin(s)
      cid_ij = CellIdx(s, mi, mj);

  ni = mi;
  nj = mj;

  avghx[1] = 0.5 * (h[NodeIdx(s, ni + 1, nj)] + h[NodeIdx(s, ni + 1, nj + 1)]);
  avghx[0] = 0.5 * (h[NodeIdx(s, ni, nj)] + h[NodeIdx(s, ni, nj + 1)]);

  avghy[1] = 0.5 * (h[NodeIdx(s, ni, nj + 1)] + h[NodeIdx(s, ni + 1, nj + 1)]);
  avghy[0] = 0.5 * (h[NodeIdx(s, ni, nj)] + h[NodeIdx(s, ni + 1, nj)]);

  gradh[0] = (avghx[1] - avghx[0]) / s->dx;
  gradh[1] = (avghy[1] - avghy[0]) / s->dy;

  norm = sqrt(gradh[0] * gradh[0] + gradh[1] * gradh[1]);

  kstar = s->k0 * pow(norm, s->d_exp);

  s->kappa[cid_ij] = kstar;

  CentroidIteratorEnd(s)

      return (0);
}

ErrorCode FESLSPMComputeDiffusivity_NonlinearPowerLaw_SACoeff(FESLSPM s, double h[])
{
  ErrorCode ierr;
  double kstar, gradh[2], norm, avghx[2], avghy[2], k0, d_exp;
  int ni, nj, nid, cid_ij;

  CentroidIteratorBegin(s)
      cid_ij = CellIdx(s, mi, mj);

  ni = mi;
  nj = mj;

  avghx[1] = 0.5 * (h[NodeIdx(s, ni + 1, nj)] + h[NodeIdx(s, ni + 1, nj + 1)]);
  avghx[0] = 0.5 * (h[NodeIdx(s, ni, nj)] + h[NodeIdx(s, ni, nj + 1)]);

  avghy[1] = 0.5 * (h[NodeIdx(s, ni, nj + 1)] + h[NodeIdx(s, ni + 1, nj + 1)]);
  avghy[0] = 0.5 * (h[NodeIdx(s, ni, nj)] + h[NodeIdx(s, ni + 1, nj)]);

  gradh[0] = (avghx[1] - avghx[0]) / s->dx;
  gradh[1] = (avghy[1] - avghy[0]) / s->dy;

  norm = sqrt(gradh[0] * gradh[0] + gradh[1] * gradh[1]);

  {
    double avg[] = {0.0, 0.0};

    avg[0] += s->k0_n[NodeIdx(s, mi, mj)];
    avg[0] += s->k0_n[NodeIdx(s, mi + 1, mj)];
    avg[0] += s->k0_n[NodeIdx(s, mi, mj + 1)];
    avg[0] += s->k0_n[NodeIdx(s, mi + 1, mj + 1)];

    avg[1] += s->d_exp_n[NodeIdx(s, mi, mj)];
    avg[1] += s->d_exp_n[NodeIdx(s, mi + 1, mj)];
    avg[1] += s->d_exp_n[NodeIdx(s, mi, mj + 1)];
    avg[1] += s->d_exp_n[NodeIdx(s, mi + 1, mj + 1)];

    k0 = 0.25 * avg[0];
    d_exp = 0.25 * avg[1];
  }

  kstar = k0 * pow(norm, d_exp);

  s->kappa[cid_ij] = kstar;

  CentroidIteratorEnd(s)

      return (0);
}

ErrorCode FESLSPMComputeDiffusivity(FESLSPM s, double h[])
{
  ErrorCode ierr;

  switch (s->mode)
  {
  case DM_CONST:
    ierr = FESLSPMComputeDiffusivity_Constant(s, h);
    break;
  case DM_NONLINEAR_CRITICALSLOPE:
    ierr = FESLSPMComputeDiffusivity_NonlinearCriticalSlope(s, h);
    break;
  case DM_NONLINEAR_POWERLAW:
    ierr = FESLSPMComputeDiffusivity_NonlinearPowerLaw(s, h);
    break;
  case DM_UNDEFINED:
    break;
  }

  {
    int cid_ij;

    CentroidIteratorBegin(s)
        cid_ij = CellIdx(s, mi, mj);

    if (s->kappa[cid_ij] < 0.0)
      ERRQ("kappa < 0");

    CentroidIteratorEnd(s)
  }

  return (0);
}

ErrorCode FESLSPMComputeDiffusivity_SpatialAveragedCoefficients(FESLSPM s, double h[])
{
  ErrorCode ierr;

  switch (s->mode)
  {
  case DM_CONST:
    ierr = FESLSPMComputeDiffusivity_Constant_SACoeff(s, h);
    break;
  case DM_NONLINEAR_CRITICALSLOPE:
    ierr = FESLSPMComputeDiffusivity_NonlinearCriticalSlope_SACoeff(s, h);
    break;
  case DM_NONLINEAR_POWERLAW:
    ierr = FESLSPMComputeDiffusivity_NonlinearPowerLaw_SACoeff(s, h);
    break;
  case DM_UNDEFINED:
    break;
  }

  {
    int cid_ij;

    CentroidIteratorBegin(s)
        cid_ij = CellIdx(s, mi, mj);

    if (s->kappa[cid_ij] < 0.0)
      ERRQ("kappa < 0");

    CentroidIteratorEnd(s)
  }

  return (0);
}

/*
 Explicit timestep:
 dt = min( h/u_vert , dx^2/kappa , dy^2/kappa )
*/
/*
ErrorCode FESLSPMComputeTimestep_explicit(FESLSPM s,double h[],double *dt)
{
    ErrorCode ierr;
    double dt_min,dx2,dy2,kappa,_dtx,_dty;
    int cidx;

    dx2 = s->dx * s->dx;
    dy2 = s->dy * s->dy;
    dt_min = 1.0e32;
    CentroidIteratorBegin(s)
    cidx = CellIdx(s,mi,mj);

    kappa = s->kappa[cidx];
    _dtx = dx2/kappa;
    _dty = dy2/kappa;
    if (_dtx < dt_min) dt_min = _dtx;
    if (_dty < dt_min) dt_min = _dty;
    CentroidIteratorEnd(s)
    *dt = dt_min;

    return(0);
}
*/

/*
 dt kappa (1/dx^2 + 1/dy^2) < 0.5
 dt = 0.5 / kappa / (sx + sy)
*/
ErrorCode FESLSPMComputeTimestep_explicit(FESLSPM s, double h[], double *dt)
{
  ErrorCode ierr;
  double dt_min, ds, sx, sy, fac, kappa, _dt;
  int cidx;

  sx = 1.0 / (s->dx * s->dx);
  sy = 1.0 / (s->dy * s->dy);
  fac = 0.5 / (sx + sy);
  dt_min = 1.0e32;
  CentroidIteratorBegin(s)
      cidx = CellIdx(s, mi, mj);

  kappa = s->kappa[cidx];
  _dt = fac / kappa;
  if (_dt < dt_min)
    dt_min = _dt;
  CentroidIteratorEnd(s)

      *dt = dt_min * s->dt_theta;

  return (0);
}

ErrorCode FESLSPMComputeTimestep_const(FESLSPM s, double *dt)
{
  ErrorCode ierr;
  *dt = s->dt_const;
  return (0);
}

ErrorCode FESLSPMComputeTimestep(FESLSPM s, double h[], double *dt)
{
  ErrorCode ierr;

  switch (s->dtmode)
  {
  case DTM_CONST:
    ierr = FESLSPMComputeTimestep_const(s, dt);
    break;
  case DTM_EXPLICIT:
  {
    double dt_d, dt_a;
    ierr = FESLSPMComputeTimestep_explicit(s, h, &dt_d);
    ierr = FESLSPMComputeTimestep_CFL(s, s->u_h, &dt_a);
    if (dt_d < dt_a)
    {
      *dt = dt_d;
    }
    else
    {
      *dt = dt_a;
    }
  }
  break;
  }
  if (*dt < 0.0)
    ERRQ("Timestep is negative");
  if (isnan(*dt))
    ERRQ("Timestep is NaN");
  if (isinf(*dt))
    ERRQ("Timestep is Inf");
  if (*dt < s->dt_min)
  {
    *dt = s->dt_min;
  }
  if (*dt > s->dt_max)
  {
    *dt = s->dt_max;
  }
  if (*dt > s->time_end)
    ERRQ("Timestep is larger than final time");
  return (0);
}

/*

 Non-conservative implementation using cell centered defined fluxes

 (i) compute kappa_x+ as 0.5(kappa_B + kappa_D)
     compute kappa_x- as 0.5(kappa_A + kappa_C)

 (ii) compute kappa_y+ as 0.5(kappa_A + kappa_B)
      compute kappa_y- as 0.5(kappa_C + kappa_D)

 ______ ______
|      |      |
|   A  |   B  |
|______|______|
|      |      |
|   C  |   D  |
|______|______|

*/
ErrorCode FESLSPMUpdate_VariableDiffusivity(FESLSPM s, double hc[])
{
  ErrorCode ierr;
  double qx[2], qy[2];
  double kx[2], ky[2], div_q;
  int nidx_ij;

  NodalIteratorInteriorBegin(s)
      nidx_ij = NodeIdx(s, ni, nj);

  kx[1] = 0.5 * (s->kappa[CellIdx(s, ni, nj)] + s->kappa[CellIdx(s, ni, nj - 1)]);
  kx[0] = 0.5 * (s->kappa[CellIdx(s, ni - 1, nj)] + s->kappa[CellIdx(s, ni - 1, nj - 1)]);

  ky[1] = 0.5 * (s->kappa[CellIdx(s, ni, nj)] + s->kappa[CellIdx(s, ni - 1, nj)]);
  ky[0] = 0.5 * (s->kappa[CellIdx(s, ni, nj - 1)] + s->kappa[CellIdx(s, ni - 1, nj - 1)]);

  qx[1] = -kx[1] * (hc[NodeIdx(s, ni + 1, nj)] - hc[NodeIdx(s, ni, nj)]) / s->dx;
  qx[0] = -kx[0] * (hc[NodeIdx(s, ni, nj)] - hc[NodeIdx(s, ni - 1, nj)]) / s->dx;

  qy[1] = -ky[1] * (hc[NodeIdx(s, ni, nj + 1)] - hc[NodeIdx(s, ni, nj)]) / s->dy;
  qy[0] = -ky[0] * (hc[NodeIdx(s, ni, nj)] - hc[NodeIdx(s, ni, nj - 1)]) / s->dy;

  div_q = (qx[1] - qx[0]) / s->dx + (qy[1] - qy[0]) / s->dy;

  s->h[nidx_ij] = hc[nidx_ij] + s->dt * s->u_v[nidx_ij] - s->dt * div_q;

  NodalIteratorInteriorEnd(s)

      return (0);
}

/*
 Standard five point Laplace operator
*/
ErrorCode FESLSPMUpdate_ConstantDiffusion(FESLSPM s, double hc[])
{
  ErrorCode ierr;
  double nabla2T, idx2, idy2, div_q;
  int nidx_ij;

  NodalIteratorInteriorBegin(s)
      nidx_ij = NodeIdx(s, ni, nj);

  idx2 = 1.0 / (s->dx * s->dx);
  idy2 = 1.0 / (s->dy * s->dy);

  nabla2T = idx2 * (hc[NodeIdx(s, ni + 1, nj)] - 2.0 * hc[nidx_ij] + hc[NodeIdx(s, ni - 1, nj)]);
  nabla2T += idy2 * (hc[NodeIdx(s, ni, nj + 1)] - 2.0 * hc[nidx_ij] + hc[NodeIdx(s, ni, nj - 1)]);

  div_q = s->k0 * nabla2T;

  s->h[nidx_ij] = hc[nidx_ij] + s->dt * s->u_v[nidx_ij] + s->dt * div_q;

  NodalIteratorInteriorEnd(s)

      return (0);
}

/*
 Standard five point Laplace operator, with cell averaged diffusivty applied as a constant
*/
ErrorCode FESLSPMUpdate_ConstantAveragedDiffusion(FESLSPM s, double hc[])
{
  ErrorCode ierr;
  double nabla2T, idx2, idy2, div_q, avg_kappa;
  int nidx_ij;

  NodalIteratorInteriorBegin(s)
      nidx_ij = NodeIdx(s, ni, nj);

  idx2 = 1.0 / (s->dx * s->dx);
  idy2 = 1.0 / (s->dy * s->dy);

  nabla2T = idx2 * (hc[NodeIdx(s, ni + 1, nj)] - 2.0 * hc[nidx_ij] + hc[NodeIdx(s, ni - 1, nj)]);
  nabla2T += idy2 * (hc[NodeIdx(s, ni, nj + 1)] - 2.0 * hc[nidx_ij] + hc[NodeIdx(s, ni, nj - 1)]);

  avg_kappa = s->kappa[CellIdx(s, ni - 1, nj - 1)];
  avg_kappa += s->kappa[CellIdx(s, ni, nj - 1)];
  avg_kappa += s->kappa[CellIdx(s, ni - 1, nj)];
  avg_kappa += s->kappa[CellIdx(s, ni, nj)];
  avg_kappa = 0.25 * avg_kappa;

  div_q = avg_kappa * nabla2T;

  s->h[nidx_ij] = hc[nidx_ij] + s->dt * s->u_v[nidx_ij] + s->dt * div_q;

  NodalIteratorInteriorEnd(s)

      return (0);
}

ErrorCode FESLSPMUpdate_EnforceBoundaryConditions(FESLSPM s, double field[])
{
  int ni, nj, nidx_ij, nidx_neighbour;

  /* update interior first to avoid order dependence */
  if (s->bctype[DIR_JMAX] == 'N')
  { /* north */
    nj = s->ny - 1;
    for (ni = 1; ni < s->nx - 1; ni++)
    {
      nidx_ij = NodeIdx(s, ni, nj);
      nidx_neighbour = NodeIdx(s, ni, nj - 1);
      field[nidx_ij] = field[nidx_neighbour];
    }
  }
  if (s->bctype[DIR_JMIN] == 'N')
  { /* south */
    nj = 0;
    for (ni = 1; ni < s->nx - 1; ni++)
    {
      nidx_ij = NodeIdx(s, ni, nj);
      nidx_neighbour = NodeIdx(s, ni, nj + 1);
      field[nidx_ij] = field[nidx_neighbour];
    }
  }
  if (s->bctype[DIR_IMAX] == 'N')
  { /* east */
    ni = s->nx - 1;
    for (nj = 1; nj < s->ny - 1; nj++)
    {
      nidx_ij = NodeIdx(s, ni, nj);
      nidx_neighbour = NodeIdx(s, ni - 1, nj);
      field[nidx_ij] = field[nidx_neighbour];
    }
  }
  if (s->bctype[DIR_IMIN] == 'N')
  { /* west */
    ni = 0;
    for (nj = 1; nj < s->ny - 1; nj++)
    {
      nidx_ij = NodeIdx(s, ni, nj);
      nidx_neighbour = NodeIdx(s, ni + 1, nj);
      field[nidx_ij] = field[nidx_neighbour];
    }
  }

  /* corner updates */
  if ((s->bctype[DIR_JMAX] == 'N') && (s->bctype[DIR_IMAX] == 'N'))
  { // NE
    ni = s->nx - 1;
    nj = s->ny - 1;
    nidx_ij = NodeIdx(s, ni, nj);
    nidx_neighbour = NodeIdx(s, ni - 1, nj - 1);
    field[nidx_ij] = field[nidx_neighbour];
  }

  if ((s->bctype[DIR_JMIN] == 'N') && (s->bctype[DIR_IMAX] == 'N'))
  { // SE
    ni = s->nx - 1;
    nj = 0;
    nidx_ij = NodeIdx(s, ni, nj);
    nidx_neighbour = NodeIdx(s, ni - 1, nj + 1);
    field[nidx_ij] = field[nidx_neighbour];
  }

  if ((s->bctype[DIR_JMIN] == 'N') && (s->bctype[DIR_IMIN] == 'N'))
  { // SW
    ni = 0;
    nj = 0;
    nidx_ij = NodeIdx(s, ni, nj);
    nidx_neighbour = NodeIdx(s, ni + 1, nj + 1);
    field[nidx_ij] = field[nidx_neighbour];
  }

  if ((s->bctype[DIR_IMIN] == 'N') && (s->bctype[DIR_JMAX] == 'N'))
  { // NW
    ni = 0;
    nj = s->ny - 1;
    nidx_ij = NodeIdx(s, ni, nj);
    nidx_neighbour = NodeIdx(s, ni + 1, nj - 1);
    field[nidx_ij] = field[nidx_neighbour];
  }

  return (0);
}

ErrorCode FESLSPMUpdate_Diffusion(FESLSPM s, double hc[])
{
  ErrorCode ierr;

  switch (s->mode)
  {
  case DM_CONST:
    ierr = FESLSPMUpdate_ConstantDiffusion(s, hc);
    break;
  case DM_NONLINEAR_CRITICALSLOPE:
    ierr = FESLSPMUpdate_VariableDiffusivity(s, hc);
    break;
  case DM_NONLINEAR_POWERLAW:
    ierr = FESLSPMUpdate_ConstantAveragedDiffusion(s, hc);
    break;
  case DM_UNDEFINED:
    ERRQ("Undefined diffusivity mode detected");
    break;
  default:
    ERRQ("Unknown diffusivity mode detected");
    break;
  }

  ierr = FESLSPMUpdate_EnforceBoundaryConditions(s, s->h);

  return (0);
}

ErrorCode FESLSPMUpdate_Diffusion_SpatialAveragedCoefficients(FESLSPM s, double hc[])
{
  ErrorCode ierr;

  switch (s->mode)
  {
  case DM_CONST:
    ierr = FESLSPMUpdate_VariableDiffusivity(s, hc);
    break;
  case DM_NONLINEAR_CRITICALSLOPE:
    ierr = FESLSPMUpdate_VariableDiffusivity(s, hc);
    break;
  case DM_NONLINEAR_POWERLAW:
    ierr = FESLSPMUpdate_ConstantAveragedDiffusion(s, hc);
    break;
  case DM_UNDEFINED:
    ERRQ("Undefined diffusivity mode detected");
    break;
  default:
    ERRQ("Unknown diffusivity mode detected");
    break;
  }
  ierr = FESLSPMUpdate_EnforceBoundaryConditions(s, s->h);
  return (0);
}

ErrorCode FESLSPMView(FESLSPM s)
{
  printf("FESLSPM:\n");
  printf("  domain [%1.4e,%1.4e] x [%1.4e,%1.4e] \n", s->xrange[0], s->xrange[1], s->yrange[0], s->yrange[1]);
  printf("  nx %4d\n", s->nx);
  printf("  ny %4d\n", s->ny);
  printf("  time_end %1.4e\n", s->time_end);
  printf("  maxsteps %d\n", s->nt_max);
  printf("  output every %d\n", s->nt_io);

  printf("  timestep mode %d\n", (int)s->dtmode);
  switch (s->dtmode)
  {
  case DTM_CONST:
    printf("    dt_const %1.4e\n", s->dt_const);
    break;
  case DTM_EXPLICIT:
    printf("    dt_theta %1.4e\n", s->dt_theta);
    printf("    dt(%D) %1.4e\n", s->nt, s->dt);
    break;
  }

  printf("  diffusion mode %d\n", (int)s->mode);
  switch (s->mode)
  {
  case DM_CONST:
    printf("    k0 %1.4e\n", s->k0);
    break;
  case DM_NONLINEAR_CRITICALSLOPE:
    printf("    k0 %1.4e , m %1.4e Sc %1.4e\n", s->k0, s->d_exp, s->Sc);
    break;
  case DM_NONLINEAR_POWERLAW:
    printf("    k0 %1.4e , m %1.4e\n", s->k0, s->d_exp);
    break;
  case DM_UNDEFINED:
    break;
  }

  return (0);
}

ErrorCode FESLSPMStepInitialize(FESLSPM s)
{
  ErrorCode ierr;

  s->time = 0.0;
  s->nt = 0;

  ierr = FESLSPMUpdate_EnforceBoundaryConditions(s, s->h_ic);
  memcpy(s->h, s->h_ic, sizeof(double) * s->nnodes);
  memcpy(s->h_c, s->h_ic, sizeof(double) * s->nnodes); /* I set h_c so that the difference in height on the IC is zero */

  /*
   * NOTE: FESLSPMComputeDiffusivity() has been removed from this
   * initialization step.
   *
   * For the FEM path, spm->kappa[] is filled by FESPMAssemble()
   * called from FESPMCreate() (using the initial h field) and
   * again from FESPMDiffusionStep() at each diffusion solve.
   * There is no separate FD estimator in the FEM path.
   */

  ierr = FESLSPMCheckpoint(s);

  return (0);
}

ErrorCode FESLSPMStepDiff(FESLSPM s)
{
  ErrorCode ierr;
  int tk;

  printf("____ FESLSPM Diff integrator ____\n");
  printf("  current time/step %1.4e/%d : target time %1.4e : max steps %d\n", s->time, s->nt, s->time_end, s->nt_max);

  if (s->time >= s->time_end)
  {
    printf("  FESLSPM: No updates performed as already at target end time\n");
    return (0);
  }

  for (tk = 0; tk < s->nt_max; tk++)
  {

    memcpy(s->h_c, s->h, sizeof(double) * s->nnodes);

    ierr = FESLSPMComputeDiffusivity(s, s->h_c);
    ierr = FESLSPMComputeTimestep(s, s->h_c, &s->dt);

    if (s->time + s->dt > s->time_end)
    {
      s->dt = s->time_end - s->time;
    }

    ierr = FESLSPMUpdate_Diffusion(s, s->h_c);

    s->time += s->dt;
    s->nt++;
    printf("  step %4d: time %1.4e, dt %1.4e\n", s->nt, s->time, s->dt);

    if (s->nt % s->nt_io == 0)
    {
      ierr = FESLSPMFieldView(s, FVT_VTRB);
      ierr = FESLSPMCheckpoint(s);
    }
    if (s->time >= s->time_end)
    {
      printf("  FESLSPM: Reached target end time\n");
      break;
    }
  }
  if (tk == (s->nt_max))
  {
    printf("  FESLSPM: Reached max number of time steps permitted\n");
  }

  return (0);
}

ErrorCode FESLSPMStepDiff_TimeDependentInput(FESLSPM s, ErrorCode (*user_update_function)(FESLSPM, double, int, double, void *), void *ctx)
{
  ErrorCode ierr;
  int tk;

  printf("____ FESLSPM Diff + TimeDependentInput integrator ____\n");
  printf("  current time/step %1.4e/%d : target time %1.4e : max steps %d\n", s->time, s->nt, s->time_end, s->nt_max);

  if (s->time >= s->time_end)
  {
    printf("  FESLSPM: No updates performed as already at target end time\n");
    return (0);
  }

  for (tk = 0; tk < s->nt_max; tk++)
  {

    memcpy(s->h_c, s->h, sizeof(double) * s->nnodes);

    /* Update user fields */
    /* Note this is performed prior to the timestep calculation */
    if (user_update_function)
    {
      ierr = user_update_function(s, s->time, s->nt, s->dt, ctx);
    }

    ierr = FESLSPMComputeDiffusivity(s, s->h_c);
    ierr = FESLSPMComputeTimestep(s, s->h_c, &s->dt);

    if (s->time + s->dt > s->time_end)
    {
      s->dt = s->time_end - s->time;
    }

    ierr = FESLSPMUpdate_Diffusion(s, s->h_c);

    s->time += s->dt;
    s->nt++;
    printf("  step %4d: time %1.4e, dt %1.4e\n", s->nt, s->time, s->dt);

    if (s->nt % s->nt_io == 0)
    {
      ierr = FESLSPMFieldView(s, FVT_VTRB);
      ierr = FESLSPMCheckpoint(s);
    }
    if (s->time >= s->time_end)
    {
      printf("  FESLSPM: Reached target end time\n");
      break;
    }
  }
  if (tk == (s->nt_max))
  {
    printf("  FESLSPM: Reached max number of time steps permitted\n");
  }

  return (0);
}

ErrorCode FESLSPMStepAdvDiff(FESLSPM s)
{
  ErrorCode ierr;
  int tk;

  printf("____ FESLSPM AdvDiff integrator ____\n");
  printf("  current time/step %1.4e/%d : target time %1.4e : max steps %d\n", s->time, s->nt, s->time_end, s->nt_max);

  if (s->time >= s->time_end)
  {
    printf("  FESLSPM: No updates performed as already at target end time\n");
    return (0);
  }

  for (tk = 0; tk < s->nt_max; tk++)
  {
    /*
     * NOTE: FESLSPMComputeDiffusivity() has been removed from this loop.
     *
     * For the FEM path, spm->kappa[] is filled inside
     * FESPMDiffusionStep() via FESPMAssemble(), using the per-triangle
     * FEM kappa from the current h* field. There is no separate FD
     * estimator in the FEM path.
     */
    ierr = FESLSPMComputeTimestep(s, s->h, &s->dt);

    if (s->time + s->dt > s->time_end)
    {
      s->dt = s->time_end - s->time;
    }

    /*
     * --------------------------------------------------------
     * 1. Existing Semi-Lagrangian advection
     * --------------------------------------------------------
     */

    ierr =
        FESLSPMUpdate_SemiLagrangian(
            s,
            s->dt,
            s->h);

    /*
     * h_c = h*
     *
     * h* is the result of the
     * Semi-Lagrangian advection step.
     */
    memcpy(
        s->h_c,
        s->h,
        sizeof(double) * s->nnodes);

    /*
     * --------------------------------------------------------
     * 2. FEM diffusion + vertical velocity
     * --------------------------------------------------------
     *
     * FESPM solves:
     *
     *     (h^(n+1) - h*) / dt
     *
     *        = u_v
     *          + div(kappa grad h*)
     *
     * --------------------------------------------------------
     */

    ierr =
        FESPMDiffusionStep(
            s->fespm,
            s,
            s->h_c);

    s->time += s->dt;
    s->nt++;
    printf("  step %4d: time %1.4e, dt %1.4e\n", s->nt, s->time, s->dt);

    if (s->nt % s->nt_io == 0)
    {
      ierr = FESLSPMFieldView(s, FVT_VTRB);
      ierr = FESLSPMCheckpoint(s);
    }
    if (s->time >= s->time_end)
    {
      printf("  FESLSPM: Reached target end time\n");
      break;
    }
  }
  if (tk == (s->nt_max))
  {
    printf("  FESLSPM: Reached max number of time steps permitted\n");
  }

  return (0);
}

/*
 Accepts user defined call back function: user_update_function() (may be NULL)
 The user function is called at each time step.
 The call back enables user to change velocity, boundary conditions as a function of time

 The prototype for the call back function is
   ErrorCode user_update_function(FESLSPM s,double time,int step,double dt,void *ctx)

 The pointer ctx is for any user-dependent data which is required by user_update_function().
*/
ErrorCode FESLSPMStepAdvDiff_TimeDependentInput(FESLSPM s, ErrorCode (*user_update_function)(FESLSPM, double, int, double, void *), void *ctx)
{
  ErrorCode ierr;
  int tk;

  printf("____ FESLSPM AdvDiff + TimeDependentInput integrator ____\n");
  printf("  current time/step %1.4e/%d : target time %1.4e : max steps %d\n", s->time, s->nt, s->time_end, s->nt_max);

  if (s->time >= s->time_end)
  {
    printf("  FESLSPM: No updates performed as already at target end time\n");
    return (0);
  }

  for (tk = 0; tk < s->nt_max; tk++)
  {

    /* Update user fields */
    /* Note this is performed prior to the timestep calculation */
    if (user_update_function)
    {
      ierr = user_update_function(s, s->time, s->nt, s->dt, ctx);
    }

    ierr = FESLSPMComputeDiffusivity(s, s->h);
    ierr = FESLSPMComputeTimestep(s, s->h, &s->dt);

    if (s->time + s->dt > s->time_end)
    {
      s->dt = s->time_end - s->time;
    }

    ierr = FESLSPMUpdate_SemiLagrangian(s, s->dt, s->h);

    memcpy(s->h_c, s->h, sizeof(double) * s->nnodes);
    ierr = FESLSPMUpdate_Diffusion(s, s->h_c);

    s->time += s->dt;
    s->nt++;

    printf("  step %4d: time %1.4e, dt %1.4e\n", s->nt, s->time, s->dt);

    if (s->nt % s->nt_io == 0)
    {
      ierr = FESLSPMFieldView(s, FVT_VTRB);
      ierr = FESLSPMCheckpoint(s);
    }

    if (s->time >= s->time_end)
    {
      printf("  FESLSPM: Reached target end time\n");
      break;
    }
  }
  if (tk == (s->nt_max))
  {
    printf("  FESLSPM: Reached max number of time steps permitted\n");
  }

  return (0);
}

ErrorCode FESLSPMUpdate_TimeDepCoefficients(FESLSPM s)
{
  ErrorCode ierr;

  switch (s->mode)
  {
  case DM_CONST:
    ierr = FESLSPMUpdate_SemiLagrangian(s, s->dt, s->k0_n);
    break;
  case DM_NONLINEAR_CRITICALSLOPE:
    ierr = FESLSPMUpdate_SemiLagrangian(s, s->dt, s->k0_n);
    ierr = FESLSPMUpdate_SemiLagrangian(s, s->dt, s->d_exp_n);
    ierr = FESLSPMUpdate_SemiLagrangian(s, s->dt, s->Sc_n);
    break;
  case DM_NONLINEAR_POWERLAW:
    ierr = FESLSPMUpdate_SemiLagrangian(s, s->dt, s->k0_n);
    ierr = FESLSPMUpdate_SemiLagrangian(s, s->dt, s->d_exp_n);
    break;
  case DM_UNDEFINED:
    ERRQ("Undefined diffusivity mode detected");
    break;
  default:
    ERRQ("Unknown diffusivity mode detected");
    break;
  }
  return (0);
}

ErrorCode FESLSPMStepAdvDiff_TimeDepCoefficients(FESLSPM s)
{
  ErrorCode ierr;
  int tk;

  printf("____ FESLSPM AdvDiff + CoeffEvolution integrator ____\n");
  printf("  current time/step %1.4e/%d : target time %1.4e : max steps %d\n", s->time, s->nt, s->time_end, s->nt_max);

  if (s->time >= s->time_end)
  {
    printf("  FESLSPM: No updates performed as already at target end time\n");
    return (0);
  }

  for (tk = 0; tk < s->nt_max; tk++)
  {

    ierr = FESLSPMComputeDiffusivity_SpatialAveragedCoefficients(s, s->h);
    ierr = FESLSPMComputeTimestep(s, s->h, &s->dt);

    if (s->time + s->dt > s->time_end)
    {
      s->dt = s->time_end - s->time;
    }

    ierr = FESLSPMUpdate_SemiLagrangian(s, s->dt, s->h);
    ierr = FESLSPMUpdate_TimeDepCoefficients(s);

    memcpy(s->h_c, s->h, sizeof(double) * s->nnodes);
    ierr = FESLSPMUpdate_Diffusion_SpatialAveragedCoefficients(s, s->h_c);

    s->time += s->dt;
    s->nt++;

    if ((tk + 1) % 50 == 0)
    {
      printf("  step %4d: time %1.4e, dt %1.4e\n", s->nt, s->time, s->dt);
    }

    if (s->nt % s->nt_io == 0)
    {
      ierr = FESLSPMFieldView(s, FVT_VTRB);
      ierr = FESLSPMCheckpoint(s);
    }
    if (s->time >= s->time_end)
    {
      printf("  step %4d: time %1.4e, dt %1.4e\n", s->nt, s->time, s->dt);
      printf("  FESLSPM: Reached target end time\n");
      break;
    }
  }
  if (tk == s->nt_max)
  {
    printf("  step %4d: time %1.4e, dt %1.4e\n", s->nt, s->time, s->dt);
    printf("  FESLSPM: Reached max number of time steps permitted\n");
  }

  return (0);
}