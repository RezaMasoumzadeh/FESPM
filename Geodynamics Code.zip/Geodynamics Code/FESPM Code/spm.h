
#ifndef __spm_h__
#define __spm_h__

#include <stdio.h>
#include <stdlib.h>

typedef int ErrorCode;

typedef enum {  DM_CONST, DM_NONLINEAR_CRITICALSLOPE, DM_NONLINEAR_POWERLAW,
                DM_UNDEFINED } FDSPMDiffusionMode;
typedef enum { DTM_CONST, DTM_EXPLICIT } FDSPMTimestepMode;

typedef enum { DIR_JMAX=0, DIR_IMAX, DIR_JMIN, DIR_IMIN } FDSPMDirection;

typedef enum { FVT_ASCII, FVT_VTR, FVT_VTRB, FVT_UNDEFINED } FDSPMFieldViewType;

typedef enum { SLINTERPOLATION_BILINEAR=0,
               SLINTERPOLATION_CSPLINE,
               SLINTERPOLATION_CSPLINE_MONOTONE,
               SLINTERPOLATION_UPWIND_CSPLINE,
               SLINTERPOLATION_UPWIND_CSPLINE_MONOTONE,
               SLINTERPOLATION_UNDEFINED } SLInterpolationType;

#define FDSPM_IGNORE -1
#define FDSPM_DECIDE -2

typedef struct _p_FDSPM *FDSPM;

typedef struct _p_FESPM *FESPM;

struct _p_FDSPM {
    double xrange[2];
    double yrange[2];
    double time_end,dt,dt_const,time;
    int nx,ny,mx,my,nnodes,ncells;
    double dx,dy,dt_theta;
    int nt,nt_io,nt_max;
    FDSPMDiffusionMode mode;
    FDSPMTimestepMode dtmode;
    double *h_ic,*h,*h_c,*u_v,*u_h,*k0_n,*d_exp_n,*Sc_n; /* node */
    double *kappa; /* cell */
    double k0,d_exp,Sc;
    char bctype[4];
    double dt_min,dt_max;
    SLInterpolationType semilagrange_interpolation_type;

        /*
     * FEM diffusion module.
     */
    FESPM fespm;
};

#define FDSPMCheckIsIgnore(a) ( (int)((a)) == FDSPM_IGNORE ? 1 : 0 )

#include "spmgriditerator.h"

#define ERRQ(str) { printf("*** FDSPM ERROR: -------------------------- Error Message --------------------------\n"\
                           "*** FDSPM ERROR: %s\n"\
                           "*** FDSPM ERROR: %s() line %d in %s\n"\
                           "*** FDSPM ERROR: -------------------------- End of Error Message --------------------------\n",\
                           (str),__FUNCTION__,__LINE__,__FILE__); exit(EXIT_FAILURE); }

#define ERRQ2(str1,str2) { printf("*** FDSPM ERROR: -------------------------- Error Message --------------------------\n"\
                                  "*** FDSPM ERROR: %s %s\n"\
                                  "*** FDSPM ERROR: %s() line %d in %s\n"\
                                  "*** FDSPM ERROR: -------------------------- End of Error Message --------------------------\n",\
                                  (str1),(str2),__FUNCTION__,__LINE__,__FILE__); exit(EXIT_FAILURE); }


ErrorCode FDSPMCreate(FDSPM *s);
ErrorCode FDSPMDestroy(FDSPM *s);

ErrorCode FDSPMSetGeometry(FDSPM s,double x0,double x1,double y0,double y1);
ErrorCode FDSPMSetResolution(FDSPM s,int nx,int ny);

ErrorCode FDSPMSetTimestepBounds(FDSPM spm,double dt_min,double dt_max);
ErrorCode FDSPMSetTimestep(FDSPM s,double dt);
ErrorCode FDSPMSetTimestepTheta(FDSPM s,double theta);
ErrorCode FDSPMSetMaxNumberSteps(FDSPM s,int nt_max);
ErrorCode FDSPMSetEndTime(FDSPM s,double tend);
ErrorCode FDSPMSetTimestepMode(FDSPM s,FDSPMTimestepMode mode);
ErrorCode FDSPMSetTimestepIO(FDSPM s,int nt);
ErrorCode FDSPMSetConstantTimestep(FDSPM s,double dt);
ErrorCode FDSPMSetExplicitTimestep(FDSPM s,double theta);

ErrorCode FDSPMSetDiffusionMode(FDSPM s,FDSPMDiffusionMode mode);
ErrorCode FDSPMSetConstantDiffusivity(FDSPM s,double k0);
ErrorCode FDSPMSetNonlinearDiffusivityCriticalSlope(FDSPM s,double k0,double Sc,double d_exp);
ErrorCode FDSPMSetNonlinearDiffusivityPowerLaw(FDSPM s,double k0,double d_exp);

ErrorCode FDSPMSetInitialHeight(FDSPM s,double h0[]);
ErrorCode FDSPMSetVerticalVelocity(FDSPM s,double v[]);
ErrorCode FDSPMSetHorizontalVelocity(FDSPM s,double uw[]);

ErrorCode FDSPMSetBoundaryConditions(FDSPM s,const char bctype[]);
ErrorCode FDSPMUpdate_EnforceBoundaryConditions(FDSPM s,double field[]);

ErrorCode FDSPMGetNodeCoordinate(FDSPM s,int i,int j,double coor[]);
ErrorCode FDSPMGetCentroidCoordinate(FDSPM s,int i,int j,double coor[]);
ErrorCode FDSPMGetVerticalVelocity(FDSPM s,int *m,int *n,double **data);
ErrorCode FDSPMGetHorizontalVelocity(FDSPM s,int *m,int *n,double **data);
ErrorCode FDSPMGetKappa(FDSPM s,int *m,int *n,double **data);
ErrorCode FDSPMGetHeight(FDSPM s,int *m,int *n,double **data);

ErrorCode FDSPMFieldView_ascii(FDSPM s);
ErrorCode FDSPMFieldView_VTRB(FDSPM s,const char filename[]);
ErrorCode FDSPMFieldView_VTR(FDSPM s,const char filename[]);
ErrorCode FDSPMView_Binary(FDSPM s,const char name[]);
ErrorCode FDSPMCheckpoint(FDSPM s);
ErrorCode FDSPMFieldView(FDSPM s,FDSPMFieldViewType type);
ErrorCode FDSPMLoadFromCheckpoint(FDSPM s,const char name[]);

ErrorCode FDSPMComputeDiffusivity(FDSPM s,double h[]);

ErrorCode FDSPMComputeTimestep(FDSPM s,double h[],double *dt);

ErrorCode FDSPMView(FDSPM s);
ErrorCode FDSPMStepDiff(FDSPM s);
ErrorCode FDSPMStepDiff_TimeDependentInput(FDSPM s,ErrorCode (*user_update_function)(FDSPM,double,int,double,void*),void *ctx);
ErrorCode FDSPMStepInitialize(FDSPM s);

ErrorCode FDSPMUpdate_Diffusion(FDSPM s,double hc[]);
ErrorCode FDSPMUpdate_SemiLagrangian(FDSPM s,double dt,double hc[]);
ErrorCode FDSPMStepAdvDiff(FDSPM s);
ErrorCode FDSPMStepAdvDiff_TimeDependentInput(FDSPM s,ErrorCode (*user_update_function)(FDSPM,double,int,double,void*),void* ctx);
ErrorCode FDSPMStepAdvDiff_TimeDepCoefficients(FDSPM s);

ErrorCode FDSPMNodeDataGetRange(FDSPM s,double x[],int start,int stride,double range[]);
ErrorCode FDSPMCellDataGetRange(FDSPM s,double x[],int start,int stride,double range[]);
ErrorCode FDSPMNodeDataSet(FDSPM s,double x[],double val);
ErrorCode FDSPMCellDataSet(FDSPM s,double x[],double val);
ErrorCode FDSPMNodeDataScale(FDSPM s,double x[],double val);
ErrorCode FDSPMCellDataScale(FDSPM s,double x[],double val);
ErrorCode FDSPMNodeDataShift(FDSPM s,double x[],double val);
ErrorCode FDSPMCellDataShift(FDSPM s,double x[],double val);

ErrorCode FDSPMCreateNodalField(FDSPM s,int ncomponents,double *nodadata[]);
ErrorCode FDSPMCreateCellField(FDSPM s,int ncomponents,double *celldata[]);
ErrorCode FDSPMDestroyNodalField(FDSPM s,double **data);
ErrorCode FDSPMDestroyCellField(FDSPM s,double **data);
ErrorCode FDSPMCellGetNodeValues(FDSPM s,int ci,int cj,int ncomponents,double nodalfield[],double vertexvalues[]);
ErrorCode FDSPMProjectNodalField(FDSPM s,double nodedata[]);

ErrorCode FDSPMSetSemiLagrangeInterpolationType(FDSPM spm,SLInterpolationType type);

#endif
