#ifndef __fespm_h__
#define __fespm_h__

#include "spm.h"

typedef struct _p_FESPM *FESPM;


/*
 * Create the FEM diffusion module using the existing FDSPM grid.
 *
 * IMPORTANT:
 * Call FDSPMSetConstantDiffusivity(spm, kappa) before this
 * function, because FESPM assembles K using spm->k0.
 */
ErrorCode FESPMCreate(FDSPM spm, FESPM *fespm);


/*
 * Destroy the FEM diffusion module.
 */
ErrorCode FESPMDestroy(FESPM *fespm);


/*
 * Perform one FEM diffusion/uplift timestep after the existing
 * Semi-Lagrangian advection step.
 *
 * PDE:
 *
 *     dh/dt = u_v + div(kappa grad h)
 *
 *
 * FEM time-discrete system:
 *
 *     M H^{n+1}
 *
 *       = M H^n
 *
 *         + dt ( M U_v - K H^n )
 *
 *
 * M is the consistent mass matrix.
 *
 * A linear system is solved at every timestep.
 */
ErrorCode FESPMDiffusionStep(FESPM fespm,
                             FDSPM spm,
                             double h_old[]);


/*
 * Estimate the explicit-Euler timestep limit using
 *
 *     K q = lambda M q
 *
 * and the largest generalized eigenvalue.
 */
ErrorCode FESPMGetStableTimestep(FESPM fespm,
                                  double *dt);

#endif